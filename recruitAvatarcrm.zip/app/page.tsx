export default function HomePage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Inicio</h1>
    </div>
  )
}

