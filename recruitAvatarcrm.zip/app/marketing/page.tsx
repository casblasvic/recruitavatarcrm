export default function MarketingPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Marketing</h1>
    </div>
  )
}

