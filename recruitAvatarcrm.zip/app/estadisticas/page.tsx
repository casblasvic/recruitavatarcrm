export default function EstadisticasPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Estadísticas</h1>
    </div>
  )
}

