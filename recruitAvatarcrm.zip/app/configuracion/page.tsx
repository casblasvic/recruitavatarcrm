export default function ConfiguracionPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Configuración</h1>
      <p className="text-gray-600">Gestione la configuración del sistema</p>
    </div>
  )
}

