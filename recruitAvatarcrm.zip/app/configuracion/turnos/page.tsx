export default function TurnosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Turnos de trabajo</h1>
      <p className="text-gray-600">Gestione los turnos de trabajo</p>
    </div>
  )
}

