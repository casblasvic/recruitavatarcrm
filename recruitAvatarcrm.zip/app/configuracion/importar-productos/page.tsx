export default function ImportarProductosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Importar productos</h1>
      <p className="text-gray-600">Importe productos al sistema</p>
    </div>
  )
}

