export default function EntidadesBancariasPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Entidades bancarias</h1>
      <p className="text-gray-600">Gestione las entidades bancarias del sistema</p>
    </div>
  )
}

