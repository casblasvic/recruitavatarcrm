export default function EtiquetasCitasPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Etiquetas para citas</h1>
      <p className="text-gray-600">Gestione las etiquetas para citas del sistema</p>
    </div>
  )
}

