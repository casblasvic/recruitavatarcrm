export default function FormulariosConsentimientosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Formularios y consentimientos</h1>
      <p className="text-gray-600">Gestione los formularios y consentimientos del sistema</p>
    </div>
  )
}

