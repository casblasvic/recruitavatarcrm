export default function CatalogosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Catálogos</h1>
      <p className="text-gray-600">Gestione los catálogos del sistema</p>
    </div>
  )
}

