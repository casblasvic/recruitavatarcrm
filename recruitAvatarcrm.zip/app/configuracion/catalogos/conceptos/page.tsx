export default function CatalogoConceptosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Catálogo de conceptos</h1>
      <p className="text-gray-600">Gestione el catálogo de conceptos del sistema</p>
    </div>
  )
}

