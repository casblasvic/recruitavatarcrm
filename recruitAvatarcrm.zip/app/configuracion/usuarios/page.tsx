export default function UsuariosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Usuarios</h1>
      <p className="text-gray-600">Gestione los usuarios del sistema</p>
    </div>
  )
}

