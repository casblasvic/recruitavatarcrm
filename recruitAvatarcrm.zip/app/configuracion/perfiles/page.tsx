export default function PerfilesPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Perfiles</h1>
      <p className="text-gray-600">Gestione los perfiles de usuario</p>
    </div>
  )
}

