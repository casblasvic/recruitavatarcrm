export default function SistemaPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Sistema</h1>
      <p className="text-gray-600">Configuración general del sistema</p>
    </div>
  )
}

