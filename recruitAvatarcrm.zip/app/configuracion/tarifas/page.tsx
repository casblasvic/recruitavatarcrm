export default function TarifasPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Tarifas</h1>
      <p className="text-gray-600">Gestione las tarifas del sistema</p>
    </div>
  )
}

