export default function ImportarDatosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-4">Importar datos</h1>
      <p className="text-gray-600">Importe datos al sistema</p>
    </div>
  )
}

