export default function FacturacionPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Facturación</h1>
    </div>
  )
}

