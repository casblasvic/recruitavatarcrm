export default function StockPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Control de stock</h1>
    </div>
  )
}

