export default function AcademyPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Academy</h1>
    </div>
  )
}

