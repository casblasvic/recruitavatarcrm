export default function DocumentosPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Documentos</h1>
    </div>
  )
}

