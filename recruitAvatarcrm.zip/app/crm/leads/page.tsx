export default function LeadsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Leads</h1>
      <p className="text-gray-600 mt-2">Gestión de leads y oportunidades</p>
    </div>
  )
}

