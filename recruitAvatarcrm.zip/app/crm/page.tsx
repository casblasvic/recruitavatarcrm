export default function CRMPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">CRM</h1>
      <p className="text-gray-600 mt-2">Gestión de relaciones con clientes</p>
    </div>
  )
}

