export default function CampanasPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Campañas</h1>
      <p className="text-gray-600 mt-2">Gestión de campañas de marketing</p>
    </div>
  )
}

