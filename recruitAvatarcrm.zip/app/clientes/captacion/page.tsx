export default function CaptacionPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold">Captación de Clientes</h1>
    </div>
  )
}

